import React from 'react';
import { View, Text, Image, ImageBackground, StatusBar, TouchableOpacity } from 'react-native'
import { COLORS, icons, images } from '../constants'
const FirstPage = ({navigation}) => {

    const renderLogo = () => {
        return (
            <View style={{alignItems:'center',marginTop:290}}>
                    <Image source={icons.Scratchers}
                        style={{ width: '60%', height: 55, }}
                        resizeMode='contain'
                    />
            </View>
        )
    }

    const renderButton = () => {
        return (
            <View style={{alignItems:'center',marginTop:200}}>
                <TouchableOpacity style={{ backgroundColor: COLORS.buttonColor, width: "80%",height:50,alignItems:'center',justifyContent:'center' , borderRadius:30,}}
                onPress={()=>navigation.navigate("Register")}
                >
                    <Text style={{ color: COLORS.white,textAlign:'center',fontSize:20 }}>Register</Text>
                </TouchableOpacity>
                <TouchableOpacity style={{ backgroundColor: COLORS.white, width: "80%",height:50,alignItems:'center',justifyContent:'center' , borderRadius:30,marginTop:20}}
                onPress={()=>navigation.navigate('Login')}
                >
                    <Text style={{ color: COLORS.black,textAlign:'center',fontSize:20 }}>Login</Text>
                </TouchableOpacity>
            </View>
        )
    }

    return (
        <View style={{ flex: 1 }}>
           <StatusBar backgroundColor={"black"}/>
            <ImageBackground source={images.firstPimg}
                style={{ width: "100.5%", height: "100%",  }}
                resizeMode='cover'
            >
                {renderLogo()}
                {renderButton()}
            </ImageBackground>
        </View>
    )
}
export default FirstPage