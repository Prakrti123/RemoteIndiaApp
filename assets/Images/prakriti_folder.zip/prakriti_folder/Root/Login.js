import React from 'react';
import { View, Text, TouchableOpacity,Dimensions, Image, TextInput, StatusBar } from "react-native"
import { COLORS, icons, images } from '../constants'


const height= Dimensions.get('window').height;
const width=Dimensions.get('window').width
const Login = () => {

    const renderHeading = () => {
        return (
            <View style={{ marginTop: 10, }}>
                <Text style={{ fontSize: 35, color: COLORS.black }}>Welcome Back</Text>
                <Text style={{ fontSize: 17 }}>Use your credentials below and login to your
                    account. </Text>
            </View>
        )
    }

    const renderInput = () => {
        const [passwordVal, setPasswordVal] = React.useState(false)
        const eye_close = icons.eye_close
        const eye = icons.eye
        return (
            <View style={{ marginTop: 30 ,}}>
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, }}>
                    <Image source={icons.phone}
                    resizeMode='contain'
                        style={{ width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='Phone Number'
                        maxLength={10}
                        keyboardType='numeric'
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                
                
                
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, marginTop: 20 }}>
                    <Image source={icons.Password}
                        resizeMode='contain'
                        style={{ width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='Password'
                        secureTextEntry={!passwordVal}
                        autoCompleteType="password"
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                <TouchableOpacity
                    onPress={() => setPasswordVal(!passwordVal)}
                >

                    <Image
                        source={passwordVal ? eye : eye_close}
                        style={{
                            width: 20,
                            height: 20,
                            position: 'absolute',
                            // left: 300,
                            right: 30,
                            top: -35,
                            tintColor: COLORS.buttonColor
                        }}
                    />
                </TouchableOpacity>
                
            </View>
        )
    }


    const renderButton = () => {
        return (
            <View style={{alignItems:'center',marginTop:40,marginBottom:20,position:'absolute',bottom:20,width:'100%'}}>

                <TouchableOpacity style={{ backgroundColor: COLORS.buttonColor, width: "100%", height: 50, alignItems: 'center', justifyContent: 'center', borderRadius: 30, }}
                    // onPress={() => navigation.navigate("Register")}
                >
                    <Text style={{ color: COLORS.white, textAlign: 'center', fontSize: 20 }}>Login</Text>
                </TouchableOpacity>
            </View>
        )
    }

    return (
        <View style={{flex:1,marginHorizontal:15}}>
            <StatusBar backgroundColor={"black"} />
            {renderHeading()}
            {renderInput()}
            {renderButton()}
        </View>
    )
}
export default Login