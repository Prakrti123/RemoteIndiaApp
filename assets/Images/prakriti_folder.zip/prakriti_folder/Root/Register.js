import React from 'react';
import { View, Text, Image, TextInput, StatusBar, TouchableOpacity,ScrollView,Dimensions } from 'react-native'

import { COLORS, icons, images } from '../constants'
const height= Dimensions.get('window').height;
const width=Dimensions.get('window').width
const Register = ({navigation}) => {

    const renderHeading = () => {
        return (
            <View style={{ marginTop: 10 }}>
                <Text style={{ fontSize: 25, fontWeight: 'bold', color: COLORS.black }}>New to</Text>
                <Text style={{ fontSize: 17 }}>Enter your basic details</Text>
            </View>
        )
    }

    const renderInput = () => {
        const [passwordVal, setPasswordVal] = React.useState(false)
        const eye_close = icons.eye_close
        const eye = icons.eye
        return (
            <View style={{ marginTop: 30 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, }}>
                    <Image source={icons.phone}
                    resizeMode="contain"
                        style={{ width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='Phone Number'
                        maxLength={10}
                        keyboardType='numeric'
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, marginTop: 20 }}>
                    <Image source={icons.Fulname}
                    resizeMode='contain'
                        style={{width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='Full Name'
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, marginTop: 20 }}>
                    <Image source={icons.email}
                    resizeMode='contain'
                        style={{width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='E-mail'
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, marginTop: 20 }}>
                    <Image source={icons.TeamName}
                    resizeMode='contain'
                        style={{width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='Team Name'
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 10, borderColor: COLORS.buttonColor, elevation: 5, backgroundColor: COLORS.white, marginTop: 20 }}>
                    <Image source={icons.Password}
                    resizeMode='contain'
                        style={{width:width*.065, height:height*.0325, marginLeft: 10 }}
                    />
                    <TextInput
                        placeholder='Password'
                        secureTextEntry={!passwordVal}
                        autoCompleteType="password"
                        style={{ marginLeft: 15, fontSize: 16, width: '100%' }}
                    />
                </View>
                <TouchableOpacity
                    onPress={() => setPasswordVal(!passwordVal)}
                >

                    <Image
                        source={passwordVal ? eye : eye_close}
                        style={{
                            width: 20,
                            height: 20,
                            position: 'absolute',
                            // left: 300,
                            right: 30,
                            top: -35,
                            tintColor: COLORS.buttonColor
                        }}
                    />
                </TouchableOpacity>
                <View style={{ marginTop: 10, width: '90%' }}>
                    <Text style={{ color: COLORS.black, fontSize: 16 }}>
                        *Password must be contains 8 Characters
                        includes 1 lowercase, 1 uppercase, 1 number
                        and 1 special character
                    </Text>
                </View>
            </View>
        )
    }

    const renderButton = () => {
        return (
            <View style={{alignItems:'center',marginTop:40,marginBottom:20}}>

                <TouchableOpacity style={{ backgroundColor: COLORS.buttonColor, width: "80%", height: 50, alignItems: 'center', justifyContent: 'center', borderRadius: 30, }}
                    onPress={() => navigation.navigate("OTP")}
                >
                    <Text style={{ color: COLORS.white, textAlign: 'center', fontSize: 20 }}>Submit</Text>
                </TouchableOpacity>
            </View>
        )
    }

    return (
        <ScrollView style={{ flex: 1, paddingHorizontal: 15, backgroundColor: COLORS.white }}>
            <StatusBar backgroundColor={COLORS.white} color={COLORS.black}   />
            {renderHeading()}
            {renderInput()}
            {renderButton()}

        </ScrollView>
    )
}

export default Register
