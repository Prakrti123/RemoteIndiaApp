import React, { Component } from 'react';
import {
    View,
    Text,
    TextInput,
    Image,
    StatusBar,
    TouchableOpacity,
    StyleSheet
} from "react-native"
import { COLORS, icons, images } from '../constants'
import OTPInputView from '@twotalltotems/react-native-otp-input'

const OTP = ({navigation}) => {

    const renderHeading = () => {
        return (
            <View style={{ marginTop: 10 }}>
                <Text style={{ fontSize: 30, fontWeight: 'bold', color: COLORS.black }}>OTP</Text>
                <Text style={{ fontSize: 17 }}>6-digit OTP has been sent to your registered
                    number
                </Text>
                <View style={{ flexDirection: 'row', marginTop: 10 }}>
                    <Text style={{ fontSize: 16, color: COLORS.black }}>+91 8825167144</Text>
                    <TouchableOpacity style={{ marginLeft: 20 }}>
                        <Text style={{ color: COLORS.buttonColor, fontSize: 16 }}>Edit</Text>
                    </TouchableOpacity>
                </View>

            </View>
        )
    }

    const renderOTP = () => {
        return (
            <View style={{
                alignItems: 'center',
                // marginHorizontal: -32,
                // backgroundColor: 'red',
                height: 120,

            }}>

                <OTPInputView
                    style={{ width: '99%', }}
                    pinCount={6}
                    autoFocusOnLoad
                    codeInputFieldStyle={{
                        width: 50,
                        height: 50,
                        borderWidth: 2,
                        // backgroundColor:'#161C22',
                        borderRadius:10,
                        borderColor:COLORS.buttonColor,
                        color:COLORS.black,
                        fontSize: 29,
                        fontWeight:'bold',
                        
                    }}
                    codeInputHighlightStyle={styles.underlineStyleHighLighted}
                    onCodeFilled={(code) => {
                        console.log(`Code is ${code}, you are good to go!`)
                    }}
                />
            </View>
        )
    }

    const renderTime=()=>{
        return(
            <View style={{alignItems:'center'}}>
                <Text style={{fontSize:18,color:COLORS.black}}>00:45</Text>
            </View>
        )
    }


    const renderButton = () => {
        return (
            <View style={{alignItems:'center',marginTop:60,marginBottom:20}}>

                <TouchableOpacity style={{ backgroundColor: COLORS.buttonColor, width: "80%", height: 50, alignItems: 'center', justifyContent: 'center', borderRadius: 30, }}
                    onPress={() => navigation.navigate("BottomTab")}
                >
                    <Text style={{ color: COLORS.white, textAlign: 'center', fontSize: 20 }}>Verify</Text>
                </TouchableOpacity>
            </View>
        )
    }

    return (
        <View style={{ flex: 1, marginHorizontal: 15 }}>
            {renderHeading()}
            {renderOTP()}
            {renderTime()}
            {renderButton()}
        </View>
    )
}
export default OTP

const styles = StyleSheet.create({
    borderStyleBase: {
        width: 30,
        height: 45
    },

    // borderStyleHighLighted: {
    //     borderColor: "#03DAC6",
    // },

    // underlineStyleBase: {
    //     width: 30,
    //     height: 45,
    //     borderWidth: 0,
    //     borderBottomWidth: 1,
    // },

    underlineStyleHighLighted: {
        borderColor: "#03DAC6",
    },
});