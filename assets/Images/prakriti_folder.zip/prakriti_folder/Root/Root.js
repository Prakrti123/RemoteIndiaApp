import 'react-native-gesture-handler';
import React, { useState } from "react";
import { Text, Dimensions, View, TouchableOpacity, Image } from "react-native";
import { COLORS, icons, images } from '../constants'
// import { NavigationContainer } from '@react-navigation/native';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createSharedElementStackNavigator } from "react-navigation-shared-element";
import FirstPage from "./FirstPage"
import Login from "./Login"
import OTP from "./OTP"
import Register from "./Register"

// import Home from '../screens/Dashboard/Home'

// import BottomTab from "./Navigator/BottomTab";
// import SideDrawer from "./Navigator/SideDrawer";
import { createDrawerNavigator } from "@react-navigation/drawer";
import BottomTab from "../Navigator/BottomTab";
import { DrawerContent } from '../Navigator/DrawerContent';

import { MyOfferCouponsStackNavigator,LeaderBoardStackNavigator,ProfileStackNavigator,FollowPageStackNavigator } from '../Navigator/StackNavigator';

// import { Home } from "../screens";
// import { useState } from "react/cjs/react.production.min";

// import { NativeBaseProvider } from "native-base";
const Drawer = createDrawerNavigator();

const Stack = createSharedElementStackNavigator();

const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width



const Root = ({navigation}) => {
    const [token, setToken] = useState(null)
    const [loading, setLoading] = useState(true)


    return (
        <>
            {
                token !== null ?
                    <Stack.Navigator
                        screenOptions={{
                            useNativeDriver: true,
                            headerShown: false
                        }}
                        initialRouteName={'FirstPage'}
                        detachInactiveScreens={false}
                    >
                        <Stack.Screen
                            name="FirstPage"
                            component={FirstPage}
                        />
                        <Stack.Screen
                            name="Register"
                            component={Register}
                        />
                        <Stack.Screen
                            name="Login"
                            component={Login}
                        />
                        <Stack.Screen
                            name="OTP"
                            component={OTP}
                        />
                    </Stack.Navigator>
                    :
                    <Drawer.Navigator
                
                        screenOptions={{
                            headerShown:false,
                            headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085, }
                        }}
                        drawerContent={props => <DrawerContent {...props} />}
                    >
                        <Drawer.Screen name="BottomTab" component={BottomTab}
                            options={{
                                headerShown: false
                            }}
                        />
                        <Drawer.Screen name="MyOfferCouponsStackNavigator" component={MyOfferCouponsStackNavigator} 
                        />
                        <Drawer.Screen name="LeaderBoardStackNavigator" component={LeaderBoardStackNavigator} 
                        />
                        <Drawer.Screen name="ProfileStackNavigator" component={ProfileStackNavigator} 
                        />
                        <Drawer.Screen name="FollowPageStackNavigator" component={FollowPageStackNavigator} 
                        />
                    </Drawer.Navigator>



            }
        </>

    )
}

export default Root


