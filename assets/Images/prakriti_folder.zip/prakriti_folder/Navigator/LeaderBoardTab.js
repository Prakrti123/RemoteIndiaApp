import React from 'react';
import { Text, View, Button, ScrollView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import { exp } from 'react-native/Libraries/Animated/Easing';

import { COLORS } from "../constants"
import { LeaderBoardSeries, LeaderBoardWeekly, LeaderBoardMonthly } from '../screens';




const Tab = createMaterialTopTabNavigator();

const MyTab = () => {
    return (

        <Tab.Navigator
            // swipeEnabled={false}

            initialRouteName='Series'

            tabBarPosition='top'

            tabBarOptions={{

                activeTintColor: COLORS.buttonColor,



                labelStyle: { fontSize: 13, fontWeight: 'bold', },
                style: {
                    height: 40,
                }

            }}
            screenOptions={{
                tabBarActiveTintColor: COLORS.black

            }}
        >

            <Tab.Screen

                name='Series'
                component={LeaderBoardSeries}
                options={{ tabBarLabel: 'Series' }}
            />
            <Tab.Screen
                name='Weekly'
                component={LeaderBoardWeekly}
                options={{ tabBarLabel: 'Weekly' }}
            />
            <Tab.Screen
                name='Monthly'
                component={LeaderBoardMonthly}
                options={{ tabBarLabel: 'Monthly' }}
            />






        </Tab.Navigator>
    )
}

const LeaderBoardTab = () => {
    return (
        <View style={{ flex: 1, backgroundColor: COLORS.white, }}>
            <StatusBar backgroundColor={COLORS.buttonColor} />
            <MyTab />
        </View>
    )
}

export default LeaderBoardTab