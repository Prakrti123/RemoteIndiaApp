import React from "react";
import {
    Image,Text,View,StatusBar,Dimensions
} from 'react-native';
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import { icons, COLORS } from "../constants";
// import { Home } from "../screens";
import { HomeStackNavigator, WalletStackNavigator,LeagueStackNavigator } from "./StackNavigator";

const height= Dimensions.get('window').height;
const width=Dimensions.get('window').width

const Tab = createBottomTabNavigator();

const tabOptions = {
  activeTintColor: COLORS.black,
    
}



const BottomTab = () => {
    return (
        <Tab.Navigator
            initialRouteName="Home"
            
            tabBarOptions={tabOptions}

            screenOptions={({ route }) => ({
                headerShown: false,
                
                tabBarIcon: ({ focused }) => {
                    const tintColor = focused ? COLORS.black : COLORS.buttonColor;

                    switch (route.name) {
                        case "Home":
                            return (
                                <Image
                                    source={icons.Home}
                                    resizeMode="contain"
                                    style={{
                                        // tintColor: tintColor,
                                        width:width*.08,
                                        height:height*.04,
                                        // marginTop: 10
                                    }}
                                />
                            )

                        case "Leagues":
                            return (
                                <Image
                                    source={icons.Leagues}
                                    resizeMode="contain"
                                    style={{
                                        // tintColor: tintColor,
                                        width:width*.075,
                                        height:height*.035,
                                    }}
                                />
                            )

                        case "Wallet":
                            return (
                                <Image
                                    source={icons.BottomWallet}
                                    resizeMode="contain"
                                    style={{
                                        // tintColor: tintColor,
                                        width:width*.07,
                                        height:height*.035,
                                    }}
                                />
                            )

                        case "More":
                            return (
                                <Image
                                    source={icons.More}
                                    resizeMode="contain"
                                    style={{
                                        // tintColor: tintColor,
                                        width:width*.075,
                                        height:height*.035,
                                    }}
                                />
                            )
                        
                    }
                }
            })}
        >
           
            <Tab.Screen
                name="Home"
                component={HomeStackNavigator}
               
            />
            <Tab.Screen
                name="Leagues"
                component={LeagueStackNavigator}
            />
            <Tab.Screen
                name="Wallet"
                component={WalletStackNavigator}
            />
            <Tab.Screen
                name="More"
                component={HomeStackNavigator}
            />
            
        </Tab.Navigator>
    )
}

export default BottomTab