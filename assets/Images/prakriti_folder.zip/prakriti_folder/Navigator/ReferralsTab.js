import React from 'react';
import { Text, View, Button, ScrollView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import { exp } from 'react-native/Libraries/Animated/Easing';

import { COLORS } from "../constants"
import {LevelOne,LevelThree,LevelTwo  } from '../screens';




const Tab = createMaterialTopTabNavigator();

const MyTab = () => {
    return (

        <Tab.Navigator
            // swipeEnabled={false}

            initialRouteName='levelOne'
            
            
            tabBarOptions={{

                activeTintColor: COLORS.buttonColor,

                
                
                labelStyle: { fontSize: 13, fontWeight:'bold'},
                

            }}
            screenOptions={{
               tabBarActiveTintColor:COLORS.buttonColor
               
            }}
        >

            <Tab.Screen

                name='levelOne'
                component={LevelOne}
                options={{ tabBarLabel: 'Level 1 (0)'}}
            />
            <Tab.Screen
                name='leveltwo'
                component={LevelTwo}
                options={{ tabBarLabel: 'Level 2 (0)' }}
            />
            <Tab.Screen
                name='levelthree'
                component={LevelThree}
                options={{ tabBarLabel: 'Level 3 (0)' }}
            />






        </Tab.Navigator>
    )
}

const ReferralsTab = () => {
    return (
        <View style={{ flex: 1,backgroundColor:COLORS.white,}}>
           <StatusBar backgroundColor={COLORS.buttonColor}/>
            <MyTab  />
        </View>
    )
}

export default ReferralsTab