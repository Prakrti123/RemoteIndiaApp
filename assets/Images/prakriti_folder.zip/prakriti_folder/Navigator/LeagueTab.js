import React from 'react';
import { Text, View, Button, ScrollView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import { exp } from 'react-native/Libraries/Animated/Easing';

import { COLORS } from "../constants"
import {LeagueUpcoming,LeagueLive,LeagueCompleted  } from '../screens';




const Tab = createMaterialTopTabNavigator();

const MyTab = () => {
    return (

        <Tab.Navigator
            // swipeEnabled={false}

            initialRouteName='Upcoming'
            
            tabBarPosition='top'
            
            tabBarOptions={{

                activeTintColor: COLORS.buttonColor,

                
                
                labelStyle: { fontSize: 13, fontWeight:'bold',},
                style:{
                    height:40,
                }

            }}
            screenOptions={{
               tabBarActiveTintColor:COLORS.black
               
            }}
        >

            <Tab.Screen

                name='Upcoming'
                component={LeagueUpcoming}
                options={{ tabBarLabel: 'Upcoming'}}
            />
            <Tab.Screen
                name='Live'
                component={LeagueLive}
                options={{ tabBarLabel: 'Live' }}
            />
            <Tab.Screen
                name='Completed'
                component={LeagueCompleted}
                options={{ tabBarLabel: 'Completed' }}
            />






        </Tab.Navigator>
    )
}

const LeagueTab = () => {
    return (
        <View style={{ flex: 1,backgroundColor:COLORS.white,}}>
           <StatusBar backgroundColor={COLORS.buttonColor}/>
            <MyTab  />
        </View>
    )
}

export default LeagueTab