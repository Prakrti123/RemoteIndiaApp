import React from 'react';
import { Text, View, Button, ScrollView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import { exp } from 'react-native/Libraries/Animated/Easing';

import { COLORS } from "../constants"
import { GrandLeague, HeadToHead } from '../screens';




const Tab = createMaterialTopTabNavigator();

const MyTab = () => {
    return (

        <Tab.Navigator
            // swipeEnabled={false}

            initialRouteName='Grand League'
            
            
            tabBarOptions={{

                activeTintColor: "red",

                tabBarActiveTintColor: "black"
                ,
                labelStyle: { fontSize: 13, color: COLORS.black,},
                style: {
                    marginHorizontal:10,
                    backgroundColor:COLORS.white,
                    borderTopLeftRadius:60,
                    borderBottomRightRadius:60,
                    marginTop:10,
                    // height:35
                    
                }

            }}
            screenOptions={{
                tabBarIndicatorStyle:{backgroundColor:'red'},
               
            }}
        >

            <Tab.Screen

                name='Grang League'
                component={GrandLeague}
                options={{ tabBarLabel: 'Grang League' }}
            />
            <Tab.Screen
                name='Head to Head'
                component={HeadToHead}
                options={{ tabBarLabel: 'Head to Head' }}
            />






        </Tab.Navigator>
    )
}

const TeamTab = () => {
    return (
        <View style={{ flex: 1,backgroundColor:COLORS.white,}}>
           <StatusBar backgroundColor={COLORS.buttonColor}/>
            <MyTab  />
        </View>
    )
}

export default TeamTab