import React from 'react';
import { View, Text, TouchableOpacity, SafeAreaView, Image, Dimensions } from 'react-native'
import { DrawerContentScrollView, DrawerItem } from '@react-navigation/drawer'
import { COLORS, icons, images } from "../constants"
const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width


const LineDivider = () => {
    return (
        <View style={{ alignItems: 'center', marginTop: 15 }}>
            <View style={{ width: "95%", height: 1.8, backgroundColor: '#E4E4E4' }} />
        </View>
    )
}

export function DrawerContent(props,navigation) {

    const renderProfileImage = () => {
        return (
            <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 10, marginLeft: 10 }}>
                <View>
                    <Image source={images.Profile} style={{ width: width * .16, height: height * .082, borderRadius: 50 }} />
                </View>
                <View style={{ marginLeft: 8 }}>
                    <Text style={{ fontSize: 22, color: COLORS.black }}>Ayush Ranjan</Text>
                    <Text style={{ fontSize: 17 }}>@ayush123</Text>
                </View>
                <TouchableOpacity style={{ position: 'absolute', right: 10 }}>
                    <Image source={icons.drawerArr}
                        resizeMode='contain'
                        style={{ width: width * .08, height: height * .02 }}
                    />
                </TouchableOpacity>
            </View>
        )
    }

    const renderFollowersSection = () => {
        return (
            <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginHorizontal: 5, marginTop: 20 }}>
                <TouchableOpacity style={{ alignItems: 'center', width: "47%", backgroundColor: '#E4E4E4', borderRadius: 7, paddingTop: 2, paddingBottom: 3 }}
                    onPress={()=>{props.navigation.navigate('FollowPageStackNavigator')}}
                >
                    <Text style={{ fontSize: 16, color: COLORS.black, fontWeight: 'bold' }}>0</Text>
                    <Text style={{ fontSize: 16, color: COLORS.black }}>Followers</Text>
                </TouchableOpacity>
                <TouchableOpacity style={{ alignItems: 'center', width: "47%", backgroundColor: '#E4E4E4', borderRadius: 7, paddingTop: 2, paddingBottom: 3 }}
                    onPress={()=>{props.navigation.navigate('FollowPageStackNavigator')}}
                >
                    <Text style={{ fontSize: 16, color: COLORS.black, fontWeight: 'bold' }}>0</Text>
                    <Text style={{ fontSize: 16, color: COLORS.black, }}>Followings</Text>
                </TouchableOpacity>
            </View>
        )
    }

    const renderDraweItem = () => {
        return (
            <View style={{ marginTop: 20 }}>
                <View style={{ marginLeft: 15, }}>
                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }}
                         onPress={()=>{props.navigation.navigate('ProfileStackNavigator')}}
                    >
                        <Image source={icons.Myprofile} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        <Text style={{ fontSize: 17, marginLeft: 16, color: COLORS.black }}>My Profile</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', marginTop: 18 }}
                    onPress={()=>{props.navigation.navigate('LeaderBoardStackNavigator')}}
                    >
                        <Image source={icons.LeaderBoard} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        <Text style={{ fontSize: 17, marginLeft: 16, color: COLORS.black }}>LeaderBoard</Text>
                    </TouchableOpacity>
                </View>
                <View style={{ alignItems: 'center', marginTop: 25 }}>
                    <View style={{ width: "95%", height: 1.8, backgroundColor: '#E4E4E4' }} />
                </View>
                <View style={{ marginLeft: 15,marginTop:20 }}>
                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }}
                    onPress={()=>{props.navigation.navigate('MyOfferCouponsStackNavigator')}}
                    >
                        <Image source={icons.OfferCoupons} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        <Text style={{ fontSize: 17, marginLeft: 16, color: COLORS.black }}>My Offers & Coupons</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', marginTop: 18 }}>
                        <Image source={icons.PointSystem} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        <Text style={{ fontSize: 17, marginLeft: 16, color: COLORS.black }}>Point System</Text>
                    </TouchableOpacity>
                </View>
                <View style={{ alignItems: 'center', marginTop: 25 }}>
                    <View style={{ width: "95%", height: 1.8, backgroundColor: '#E4E4E4' }} />
                </View>
                <View style={{ marginLeft: 15,marginTop:20 }}>
                    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Image source={icons.Logout} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        <Text style={{ fontSize: 17, marginLeft: 16, color: COLORS.black }}>Logout</Text>
                    </TouchableOpacity>
                    
                </View>
            </View>
        )
    }

    const renderShare=()=>{
        return(
            <View style={{flexDirection:'row',justifyContent:'space-around',marginTop:70,marginHorizontal:10}}>
                <TouchableOpacity>
                    <Image source={icons.FaceBook} resizeMode="contain" style={{width:width*.09,height:height*.044}}/>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image source={icons.Insta} resizeMode="contain" style={{width:width*.09,height:height*.044}}/>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image source={icons.Teligram} resizeMode="contain" style={{width:width*.09,height:height*.044}}/>
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image source={icons.Twitter} resizeMode="contain" style={{width:width*.09,height:height*.044}}/>
                </TouchableOpacity>
            </View>
        )
    }

    return (
        <SafeAreaView>
            {renderProfileImage()}
            {renderFollowersSection()}
            <LineDivider />

            {renderDraweItem()}

            {renderShare()}

        </SafeAreaView>
    )
}