

import React from 'react';
import { Text, View, Button, ScrollView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import { exp } from 'react-native/Libraries/Animated/Easing';

import { COLORS } from "../constants"
import { BankTransfer,PaytmWallet } from '../screens';




const Tab = createMaterialTopTabNavigator();

const MyTab = () => {
    return (

        <Tab.Navigator
            // swipeEnabled={false}

            initialRouteName='BankTransfer'


            tabBarOptions={{

                activeTintColor: COLORS.black,



                labelStyle: { fontSize: 13, fontWeight: 'bold' },
                

            }}
            screenOptions={{
                tabBarActiveTintColor: COLORS.black,
                
            }}
        >

            <Tab.Screen

                name='BankTransfer'
                component={BankTransfer}
                options={{ tabBarLabel: 'BANK TRANSFER' }}
            />
            <Tab.Screen
                name='PaytmWallet'
                component={PaytmWallet}
                options={{ tabBarLabel: 'PAYTH WALLET' }}
            />







        </Tab.Navigator>
    )
}

const WithdrawTab = () => {
    return (
        <View style={{ flex: 1, backgroundColor: COLORS.white, }}>
            <StatusBar backgroundColor={COLORS.buttonColor} />
            <MyTab />
        </View>
    )
}

export default WithdrawTab