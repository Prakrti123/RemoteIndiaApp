// import React from 'react';
// import 'react-native-gesture-handler'
// import {Text,Image} from 'react-native'
// import { NavigationContainer } from '@react-navigation/native';

// import { createDrawerNavigator } from '@react-navigation/drawer';
// import { Home } from '../screens';
// import { DrawerContent } from './DrawerContent';


// const Drawer = createDrawerNavigator();


// const SideDrawer = () => {
 
//   return (

//     <NavigationContainer>
//       <Drawer.Navigator initialRouteName='Home'
//       drawerContent={props=> <DrawerContent {...props}/>}
//       >
//         <Drawer.Screen name="Home" component={Home}
//         options={{

//         }}
//         />
//         {/* <Drawer.Screen name="Profile" component={Profile} /> */}
//       </Drawer.Navigator>
//     </NavigationContainer>
//   );
// }

// export default SideDrawer