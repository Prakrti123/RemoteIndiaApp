import React from 'react';
import { View, Text, Image, TouchableOpacity, Dimensions } from 'react-native'
import { createStackNavigator } from '@react-navigation/stack';
import { AddCash, Home, Withdraw,RecentTransaction, FollowPage, Profile, LeaderBoard, TeamPage, Wallet, MyOfferCoupons, PaymentMethod, AccountVerification, MyReferrals, RequestStatement, League } from '../screens';
import { COLORS, icons, images } from '../constants'
import { getFocusedRouteNameFromRoute } from '@react-navigation/native';


const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width

const Stack = createStackNavigator();


const bottomBarCondition = (navigation, route, routeName) => {

    if (getFocusedRouteNameFromRoute(route) === routeName || getFocusedRouteNameFromRoute(route) === undefined) {
        navigation.setOptions({
            tabBarStyle: { borderRadius: 10, paddingVertical: 10, height: "9%", paddingBottom: 12, elevation: 10, alignItems: 'center' }
        });
    }
    else {
        navigation.setOptions({
            tabBarStyle: { display: 'none' }
        });
    }

}



const HomeStackNavigator = ({ navigation, route }) => {
    bottomBarCondition(navigation, route, "Home")
    return (
        <Stack.Navigator
            initialRouteName='Home'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085 },
             
            }}
        >
            <Stack.Screen name="Home" component={Home}
                options={{
                    headerTitle: () => (<Image source={icons.ScratchersH} resizeMode="contain" style={{ width: width * .37, height: height * .04, marginLeft: 10 }} />),
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.openDrawer()} ><Image source={icons.toggleButton} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} /></TouchableOpacity>),
                    headerRight: () => (<View style={{ flexDirection: 'row' }}>
                        <TouchableOpacity style={{ marginRight: 10 }}>
                            <Image source={icons.bellIcon} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={{ marginHorizontal: 13 }}>
                            <Image source={icons.HeaderWallet} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        </TouchableOpacity>

                    </View>)
                }}
            />
            <Stack.Screen name='TeamPage' component={TeamPage}

                options={{

                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>TEAM A vs TEAM B</Text>
                        <Text style={{ color: COLORS.white }}>06h 43m</Text>
                    </View>),
                    headerRight: () => (<View style={{ flexDirection: 'row' }}>

                        <TouchableOpacity style={{ marginRight: 20 }}>
                            <Image source={icons.HeaderWallet} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        </TouchableOpacity>
                    </View>)
                }}
            />
            {/* <Stack.Screen name="WalletQRcode" component={WalletQRcode} /> */}
        </Stack.Navigator>

    )
}


const WalletStackNavigator = ({ navigation, route }) => {
    bottomBarCondition(navigation, route, "Wallet")

    return (
        <Stack.Navigator
            initialRouteName='Wallet'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085, elevation: 0 },



            }}
        >
            <Stack.Screen name="Wallet" component={Wallet}
                options={{
                    headerTitle: "",
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.openDrawer()} ><Image source={icons.walletToggle} resizeMode="contain" style={{ width: width * .08, height: height * .045 }} /></TouchableOpacity>),

                }}
            />
            <Stack.Screen name="AddCash" component={AddCash}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Add Cash</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.openDrawer()} ><Image source={icons.walletToggle} resizeMode="contain" style={{ width: width*.08, height: height*.045 }} /></TouchableOpacity>),

                }}
            />
            <Stack.Screen name="PaymentMethod" component={PaymentMethod}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Payment Method</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.openDrawer()} ><Image source={icons.walletToggle} resizeMode="contain" style={{ width: width*.08, height: height*.045 }} /></TouchableOpacity>),

                }}
            />
            <Stack.Screen name="AccountVerification" component={AccountVerification}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Account Verification</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.openDrawer()} ><Image source={icons.walletToggle} resizeMode="contain" style={{ width: width*.08, height: height*.045 }} /></TouchableOpacity>),

                }}
            />
            <Stack.Screen name="MyReferrals" component={MyReferrals}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 17 }}>My Referrals</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width*.06, height: height*.025 }} /></TouchableOpacity>),
                    headerRight: () => (<Text style={{ marginRight: 15, fontSize: 17, color: COLORS.white }}>Referrals:0</Text>)
                }}
            />
            <Stack.Screen name="RequestStatement" component={RequestStatement}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Request Statement</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width*.06, height: height*.025 }} /></TouchableOpacity>),
                    //    headerRight:()=>(<Text style={{marginRight:15,fontSize:17,color:COLORS.white}}>Referrals:0</Text>)
                }}
            />
            <Stack.Screen name="Withdraw" component={Withdraw}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Withdraw</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width*.06, height: height*.025 }} /></TouchableOpacity>),
                    //    headerRight:()=>(<Text style={{marginRight:15,fontSize:17,color:COLORS.white}}>Referrals:0</Text>)
                }}
            />
            <Stack.Screen name="RecentTransaction" component={RecentTransaction}
                options={{
                    headerTitle: () => (<View>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Recent Transaction</Text>
                    </View>),
                    // headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width*.06, height: height*.025 }} /></TouchableOpacity>),
                    //    headerRight:()=>(<Text style={{marginRight:15,fontSize:17,color:COLORS.white}}>Referrals:0</Text>)
                }}
            />


        </Stack.Navigator>
    )
}

const LeagueStackNavigator = ({ navigation, route }) => {

    bottomBarCondition(navigation, route, "League")
    return (
        <Stack.Navigator
            initialRouteName='League'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085,  },



            }}
        >
            <Stack.Screen name="League" component={League}
                options={{
                    headerTitle: () => (<View style={{ marginLeft: 10 }}>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>League</Text>
                    </View>),
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.openDrawer()} ><Image source={icons.toggleButton} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} /></TouchableOpacity>),
                    headerRight: () => (<View style={{ flexDirection: 'row' }}>

                        <TouchableOpacity style={{ marginHorizontal: 13 }}>
                            <Image source={icons.HeaderWallet} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                        </TouchableOpacity>

                    </View>)
                }}
            />
        </Stack.Navigator>
    )
}

const MyOfferCouponsStackNavigator = ({ navigation }) => {
    return (
        <Stack.Navigator
            initialRouteName='MyOfferCoupons'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085, elevation: 0 },



            }}
        >
            <Stack.Screen name="MyOfferCoupons" component={MyOfferCoupons}
                options={{
                    headerTitle: () => (<View style={{ marginLeft: 10 }}>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>My Offer Coupons</Text>
                    </View>),
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width * .07, height: height * .03 }} /></TouchableOpacity>),
                    //     headerRight: () => (<View style={{ flexDirection: 'row' }}>

                    //     <TouchableOpacity style={{ marginHorizontal: 13 }}>
                    //         <Image source={icons.HeaderWallet} resizeMode="contain" style={{ width: width * .07, height: height * .04 }} />
                    //     </TouchableOpacity>

                    // </View>)
                }}
            />
        </Stack.Navigator>
    )
}
const LeaderBoardStackNavigator = ({ navigation }) => {
    return (
        <Stack.Navigator
            initialRouteName='LeaderBoard'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085, elevation: 0 },



            }}
        >
            <Stack.Screen name="LeaderBoard" component={LeaderBoard}
                options={{
                    headerTitle: () => (<View style={{ marginLeft: 10 }}>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Leaderboard</Text>
                    </View>),
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width * .07, height: height * .03 }} /></TouchableOpacity>),
                    headerRight: () => (<View style={{ flexDirection: 'row' }}>

                        <TouchableOpacity style={{ marginRight: 15 }}>
                            <Image source={icons.HeaderI} resizeMode="contain" style={{ width: width * .052, height: height * .03 }} />
                        </TouchableOpacity>

                    </View>)
                }}
            />
        </Stack.Navigator>
    )
}
const ProfileStackNavigator = ({ navigation }) => {
    return (
        <Stack.Navigator
            initialRouteName='Profile'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085 },



            }}
        >
            <Stack.Screen name="Profile" component={Profile}
                options={{
                    headerTitle: () => (<View style={{ marginLeft: 10 }}>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Profile</Text>
                    </View>),
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width * .07, height: height * .03 }} /></TouchableOpacity>),
                   
                }}
            />
        </Stack.Navigator>
    )
}
const FollowPageStackNavigator = ({ navigation }) => {
    return (
        <Stack.Navigator
            initialRouteName='FollowPage'

            screenOptions={{
                headerStyle: { backgroundColor: COLORS.buttonColor, height: height * .085 },



            }}
        >
            <Stack.Screen name="FollowPage" component={FollowPage}
                options={{
                    headerTitle: () => (<View style={{ marginLeft: 10 }}>
                        <Text style={{ color: COLORS.white, fontSize: 19 }}>Follow-Followers</Text>
                    </View>),
                    headerLeft: () => (<TouchableOpacity style={{ marginLeft: 15 }} onPress={() => navigation.goBack()} ><Image source={icons.BackArrow} resizeMode="contain" style={{ width: width * .07, height: height * .03 }} /></TouchableOpacity>),
                   
                }}
            />
        </Stack.Navigator>
    )
}


export {
    HomeStackNavigator,
    WalletStackNavigator,
    LeagueStackNavigator,
    MyOfferCouponsStackNavigator,
    LeaderBoardStackNavigator,
    ProfileStackNavigator,
    FollowPageStackNavigator
    // TeamStackNavigator
}
