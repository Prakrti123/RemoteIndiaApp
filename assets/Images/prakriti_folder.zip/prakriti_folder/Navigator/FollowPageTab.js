
import React from 'react';
import { Text, View, Button, ScrollView, StatusBar } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
// import { exp } from 'react-native/Libraries/Animated/Easing';

import { COLORS } from "../constants"
import {FollowPageFollowers,FollowPageFollowing} from '../screens';




const Tab = createMaterialTopTabNavigator();

const MyTab = () => {
    return (

        <Tab.Navigator
            // swipeEnabled={false}

            initialRouteName='Upcoming'
            
            tabBarPosition='top'
            
            tabBarOptions={{

                activeTintColor: COLORS.buttonColor,

                
                
                labelStyle: { fontSize: 13, fontWeight:'bold'},
                style:{
                    height:40,
                    marginTop:10,
                    marginHorizontal:15,
                    borderTopLeftRadius:100,
                    borderBottomRightRadius:100
                }

            }}
            screenOptions={{
               tabBarActiveTintColor:COLORS.black
               
            }}
        >

            <Tab.Screen

                name='Followers'
                component={FollowPageFollowers}
                options={{ tabBarLabel: 'Followers'}}
            />
            <Tab.Screen
                name='Following'
                component={FollowPageFollowing}
                options={{ tabBarLabel: 'Following' }}
            />
            





        </Tab.Navigator>
    )
}

const FollowPageTab = () => {
    return (
        <View style={{ flex: 1,}}>
           <StatusBar backgroundColor={COLORS.buttonColor}/>
            <MyTab  />
        </View>
    )
}

export default FollowPageTab