import 'react-native-gesture-handler'
import React, { useEffect } from "react";
// import { Easing } from "react-native";
import { NavigationContainer } from '@react-navigation/native';
import Root from './Root/Root';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import { createSharedElementStackNavigator } from "react-navigation-shared-element";
// import {
//   FirstPage,
//   Register,
//   Login,
//   OTP,
//   Home,


// } from "./screens";
// import BottomTab from "./Navigator/BottomTab";
// import SideDrawer from "./Navigator/SideDrawer";
// import { Root } from './Root/Root'


// import { NativeBaseProvider } from "native-base";

// const Stack = createSharedElementStackNavigator();





const App = () => {



    return (
        <NavigationContainer>
            <Root />
        </NavigationContainer>
    )
}

export default App